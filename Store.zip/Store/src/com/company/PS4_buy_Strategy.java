package com.company;

public class PS4_buy_Strategy extends BuyerBase {
    @Override
    public double doStrategy() {
        return 35.25;
    }
}
