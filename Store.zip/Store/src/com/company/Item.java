package com.company;

public abstract class Item {

    int _priceCode;
}
