package com.company;

import java.util.Enumeration;
import java.util.Vector;

public class Customer {
    private String _name;
    private Vector _rcart = new Vector();
    private Vector _bcart = new Vector();

    public Customer (String name) {
        _name = name;
    }

    public void addRental(Rental arg) {
        _rcart.addElement(arg);
    }

    public void addBuyer(Buyer arg) {
        _bcart.addElement(arg);
    }

    public String getName() {
        return _name;
    }

    public String statement() {

        double      totalAmount          = 0;
        int         frequentRenterPoints = 0;
        Enumeration rcart              = _rcart.elements();
        Enumeration bcart              = _bcart.elements();
        String      result               = "Store Record for " + getName() + "\n";

        while (rcart.hasMoreElements()) {

            Rental each       = (Rental) rcart.nextElement();

            totalAmount += each.getCost();
            frequentRenterPoints= each.updateRenterPoints(frequentRenterPoints);
        }

        while (bcart.hasMoreElements()) {

            Buyer each       = (Buyer) bcart.nextElement();

            totalAmount+= each.getCost();
        }

        // add footer lines
        result += "Amount owed is " + String.valueOf(totalAmount) + "$\n";
        result += "You earned " + String.valueOf(frequentRenterPoints) +
                " frequent renter points";
        return result;
    }
}