package com.company;

public class Movie_rental_Old_Strategy extends RentalBase{

    @Override
    public double doStrategy(int days) {
        return 1.5*(days - 3);
    }
}
