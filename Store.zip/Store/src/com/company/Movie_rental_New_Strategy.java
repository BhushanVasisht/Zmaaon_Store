package com.company;

public class Movie_rental_New_Strategy extends RentalBase{

    @Override
    public double doStrategy(int days) {
        return 3.0*(days - 3);
    }
}