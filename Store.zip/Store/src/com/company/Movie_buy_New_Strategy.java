package com.company;

public class Movie_buy_New_Strategy extends BuyerBase {
    @Override
    public double doStrategy() {
        return 10.00;
    }
}
