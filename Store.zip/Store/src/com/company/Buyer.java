package com.company;

public class Buyer {
    private Movie _movie;
    private MusicCD _musicCD;
    private PS4 _ps4;
    private Xbox _xbox;
    private Games _games;

    public Item it;

    private int itCo;

    private BuyerBase bb;

    public Buyer(int itemcode, String itemname, int typecode) {
        it = new BuyerItemFactory().getinstance(itemcode, itemname, typecode);
        itCo = itemcode;
    }

    public Item getItem() {
        return it;
    }

    public double getCost()
    {
        bb = null;

        if(itCo == 0)
        {
            if(it._priceCode > 0)
            {
                bb = new Movie_buy_New_Strategy();
            }
            else
            {
                bb = new Movie_buy_Old_Strategy();
            }

        }
        if(itCo == 1)
        {
            bb = new MusicCD_buy_Strategy();

        }
        if(itCo == 2)
        {
            bb = new PS4_buy_Strategy();
        }
        if(itCo == 3)
        {
            bb = new Xbox_buy_Strategy();
        }
        if(itCo == 4)
        {
            bb = new Games_buy_Strategy();
        }
        if(itCo == 5)
        {
            bb = new Books_buy_Strategy();
        }

        return bb.doStrategy();
    }

}