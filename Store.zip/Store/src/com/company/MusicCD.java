package com.company;

public class MusicCD extends Item {

    public static final int BALLE   = 2;
    public static final int REGULAR     = 0;
    public static final int FILMY = 1;

    private String _title;
    private int    _priceCode;

    public MusicCD(String title, int priceCode) {
        _title = title;
        _priceCode = priceCode;
    }

    public int getPriceCode() {
        return _priceCode;
    }

    public void setPriceCode(int arg) {
        _priceCode = arg;
    }

    public String getTitle() {
        return _title;
    }
}
