package com.company;

public class Books_rental_Strategy extends RentalBase {
    @Override
    public double doStrategy(int days) {
        return 2.99;
    }
}
