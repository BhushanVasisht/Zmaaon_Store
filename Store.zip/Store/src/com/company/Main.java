package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // write your code here

        Scanner rd = new Scanner(System.in);


        Rental r1 = new Rental(0, "IT", 4, 0);
        Rental r2 = new Rental(0,"Pride", 2, 2);
        Rental r3 = new Rental(0,"Shazam", 10, 1);
        Rental r4 = new Rental(1, "Beethovan Classic", 7, 0);
        Rental r5 = new Rental(2, "Spiderman", 10, 1);


        Buyer b3 = new Buyer(5,"CLRS", 1);
        Buyer b4 = new Buyer(1, "Beethovan Classic", 0);
        Buyer b5 = new Buyer(2, "Spiderman", 1);
        Buyer b6 = new Buyer(3,"FIFA19", 0);
        Buyer b7 = new Buyer(4, "Roadrage", 2);


        Customer c1 = new Customer("Bhushan");

        c1.addRental(r1);
        c1.addRental(r2);
        c1.addRental(r3);
        c1.addRental(r4);
        c1.addRental(r5);


        c1.addBuyer(b3);
        c1.addBuyer(b4);
        c1.addBuyer(b5);
        c1.addBuyer(b6);
        c1.addBuyer(b7);

        System.out.println(c1.statement());
    }
}
