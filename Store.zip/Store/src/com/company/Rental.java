package com.company;

public class Rental {

    public Item it;
    public int   _daysRented;

    private RentalBase rb;

    private int itCo;

    public Rental(int itemcode, String itemname,  int daysRented, int priceCode) {

        it = new RentalItemFactory().getinstance(itemcode, itemname, priceCode);
        _daysRented = daysRented;
        itCo = itemcode;
    }

    public double getCost()
    {
        rb = null;

        if(itCo == 0)
        {
            if(it._priceCode > 0)
            {
                rb = new Movie_rental_New_Strategy();
            }
            else
            {
                rb = new Movie_rental_Old_Strategy();
            }

        }
        if(itCo == 1)
        {
            rb = new MusicCD_rental_Strategy();

        }
        if(itCo == 2)
        {
            rb = new PS4_rental_Strategy();
        }
        if(itCo == 3)
        {
            rb = new Xbox_rental_Strategy();
        }
        if(itCo == 4)
        {
            rb = new Games_rental_Strategy();
        }
        if(itCo == 5)
        {
            rb = new Books_rental_Strategy();
        }

        return rb.doStrategy(_daysRented);
    }

    public int updateRenterPoints(int pt)
    {
        return (pt+1);
    }
}