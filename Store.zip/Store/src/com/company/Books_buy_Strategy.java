package com.company;

public class Books_buy_Strategy extends BuyerBase {
    @Override
    public double doStrategy() {
        return 5.99;
    }
}
