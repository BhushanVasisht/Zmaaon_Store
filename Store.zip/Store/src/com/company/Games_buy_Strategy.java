package com.company;

public class Games_buy_Strategy extends BuyerBase {
    @Override
    public double doStrategy() {
        return 9.99;
    }
}
