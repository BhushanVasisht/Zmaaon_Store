package com.company;

public class Xbox_rental_Strategy extends RentalBase {
    @Override
    public double doStrategy(int days) {
        return 3.1*days;
    }
}
