package com.company;

public abstract class FrequentRentalPointsBase {

    public abstract int calculateRentalPoints(int pt);

}
