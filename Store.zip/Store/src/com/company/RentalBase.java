package com.company;

public abstract class RentalBase {

    public abstract double doStrategy(int days);
}
