package com.company;

public class Xbox extends Item {
    public static final int OLD   = 1;
    public static final int NEW     = 0;

    private String _title;
    private int    _priceCode;

    public Xbox(String title, int priceCode) {
        _title = title;
        _priceCode = priceCode;
    }

    public int getPriceCode() {
        return _priceCode;
    }

    public void setPriceCode(int arg) {
        _priceCode = arg;
    }

    public String getTitle() {
        return _title;
    }
}
