package com.company;

public class PS4_rental_Strategy extends RentalBase {
    @Override
    public double doStrategy(int days) {
        return days * 2.1;
    }
}
