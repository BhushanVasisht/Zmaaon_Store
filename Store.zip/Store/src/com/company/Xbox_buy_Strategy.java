package com.company;

public class Xbox_buy_Strategy extends BuyerBase {
    @Override
    public double doStrategy() {
        return 62.56;
    }
}
