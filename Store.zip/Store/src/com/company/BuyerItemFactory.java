package com.company;

public class BuyerItemFactory {

    public Item getinstance(int itemcode, String itemname, int typecode)
    {
        switch(itemcode)
        {
            case 0:
            {
                return new Movie(itemname, typecode);
            }

            case 1:
            {
                return new MusicCD(itemname, typecode);
            }

            case 2:
            {
                return new PS4(itemname, typecode);
            }

            case 3:
            {
                return new Xbox(itemname, typecode);
            }

            case 4:
            {
                return new Games(itemname, typecode);
            }
        }

        return null;
    }
}