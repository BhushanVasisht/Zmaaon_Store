package com.company;

public class MusicCD_rental_Strategy extends RentalBase {

    @Override
    public double doStrategy(int days) {
        return days*1.1;
    }
}
