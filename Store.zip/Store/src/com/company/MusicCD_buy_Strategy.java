package com.company;

public class MusicCD_buy_Strategy extends BuyerBase {
    @Override
    public double doStrategy() {
        return 2.99;
    }
}
