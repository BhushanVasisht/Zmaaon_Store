package com.company;

public class Movie_buy_Old_Strategy extends BuyerBase {
    @Override
    public double doStrategy() {
        return 5.75;
    }
}
