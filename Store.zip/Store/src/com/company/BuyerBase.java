package com.company;

public abstract class BuyerBase {

    public abstract double doStrategy();
}
